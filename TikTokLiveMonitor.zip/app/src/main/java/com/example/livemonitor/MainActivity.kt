package com.example.livemonitor

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var username: EditText
    private lateinit var status: TextView
    private lateinit var events: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private var running = false
    private var lastRead = 0L
    private val logFile by lazy { File(filesDir, "events.jsonl") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 36, 32, 24); setBackgroundColor(0xFF10131B.toInt()) }
        root.addView(TextView(this).apply { text = "مراقب بث تيك توك"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt()) }, match())
        root.addView(TextView(this).apply { text = "مراقبة الأحداث المهمة • سجل محلي • تنبيهات"; textSize = 14f; gravity = Gravity.CENTER; setTextColor(0xFFB9C5D8.toInt()) }, match())
        username = EditText(this).apply { hint = "يوزر صاحب البث بدون @"; setSingleLine(true); setTextColor(-1); setHintTextColor(0xFF8D98A8.toInt()) }
        root.addView(username, match())
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        buttons.addView(Button(this).apply { text = "بدء المراقبة"; setOnClickListener { startMonitor() } }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply { text = "إيقاف"; setOnClickListener { stopMonitor() } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons, match())
        status = TextView(this).apply { text = "جاهز"; textSize = 16f; setTextColor(0xFF70E1B5.toInt()); setPadding(0, 18, 0, 18) }
        root.addView(status, match())
        root.addView(TextView(this).apply { text = "سجل الأحداث"; textSize = 20f; setTextColor(-1) }, match())
        events = TextView(this).apply { text = "ماكو أحداث بعد."; textSize = 14f; setTextColor(0xFFE0E6F0.toInt()); setPadding(12, 12, 12, 12) }
        val scroll = ScrollView(this); scroll.addView(events); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshLog()
    }

    private fun startMonitor() {
        val handle = username.text.toString().trim().removePrefix("@").trim()
        if (handle.isBlank()) { username.error = "اكتب يوزر البث"; return }
        if (running) return
        running = true; status.text = "جاري الاتصال بـ @$handle …"
        executor.execute {
            try {
                logFile.parentFile?.mkdirs()
                Python.getInstance().getModule("monitor").callAttr("start_monitor", handle, filesDir.absolutePath)
            } catch (e: Exception) {
                runOnUiThread { status.text = "تعذر التشغيل: ${e.message ?: "خطأ غير معروف"}"; running = false }
            }
        }
        // Python monitor runs until disconnect; poll its event log while the connection is active.
        events.postDelayed(object : Runnable { override fun run() { refreshLog(); if (running) events.postDelayed(this, 1500) } }, 500)
    }

    private fun stopMonitor() {
        running = false
        try { Python.getInstance().getModule("monitor").callAttr("stop_monitor") } catch (_: Exception) {}
        status.text = "تم طلب الإيقاف"; refreshLog()
    }

    private fun refreshLog() {
        if (!logFile.exists()) return
        try {
            val lines = logFile.readLines()
            if (lines.size.toLong() <= lastRead) return
            val newLines = lines.drop(lastRead.toInt())
            lastRead = lines.size.toLong()
            val display = newLines.mapNotNull { line ->
                try {
                    val obj = org.json.JSONObject(line)
                    val type = obj.optString("type", "حدث")
                    val flagged = obj.optBoolean("flag", false)
                    val time = obj.optString("time", "")
                    if (flagged) notifyImportant(type, time)
                    "${if (flagged) "⭐" else "•"} $type  $time"
                } catch (_: Exception) { null }
            }
            if (display.isNotEmpty()) events.text = (display.reversed() + events.text.lines().filter { it.isNotBlank() && it != "ماكو أحداث بعد." }).take(200).joinToString("\n")
        } catch (_: Exception) {}
    }

    private fun notifyImportant(type: String, time: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val n = android.app.Notification.Builder(this, "important_events")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("حدث مهم في بث تيك توك")
            .setContentText("$type ${if (time.isNotBlank()) "• $time" else ""}")
            .setAutoCancel(true).build()
        nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("important_events", "أحداث مهمة", NotificationManager.IMPORTANCE_DEFAULT)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
