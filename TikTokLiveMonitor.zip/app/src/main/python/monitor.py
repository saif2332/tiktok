# Prototype TikTokLive monitor for the Android app. Runs without browser cookies.
import asyncio, json, os, time, threading
from TikTokLive import TikTokLiveClient
from TikTokLive.events import ConnectEvent, DisconnectEvent, LiveEndEvent

KEYWORDS = ("box", "treasure", "chest", "lucky", "reward", "redpacket", "red_packet", "envelope", "gift", "coin", "bonus", "task")
_stop = threading.Event()
_loop = None
_client = None


def _important(name, data):
    text = (name + " " + json.dumps(data, ensure_ascii=False, default=str)).lower()
    return any(k in text for k in KEYWORDS)


def start_monitor(handle, app_dir):
    global _loop, _client
    _stop.clear()
    path = os.path.join(app_dir, "events.jsonl")
    _client = TikTokLiveClient(unique_id=handle.lstrip("@"))
    async def run():
        global _loop
        _loop = asyncio.get_running_loop()
        with open(path, "a", encoding="utf-8") as out:
            async def record(event):
                name = type(event).__name__
                try:
                    data = event.dict() if hasattr(event, "dict") else vars(event)
                except Exception:
                    data = {"repr": repr(event)}
                flag = _important(name, data)
                rec = {"time": time.strftime("%H:%M:%S"), "type": name, "flag": flag, "data": data}
                out.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
                out.flush()
            # Subscribe to known event classes and available event types from this library version.
            from TikTokLive import events
            for name in dir(events):
                cls = getattr(events, name, None)
                if isinstance(cls, type) and name.endswith("Event"):
                    try:
                        _client.add_listener(cls, record)
                    except Exception:
                        pass
            try:
                await _client.connect()
                while not _stop.is_set() and getattr(_client, "connected", False):
                    await asyncio.sleep(0.5)
            finally:
                try: await _client.disconnect()
                except Exception: pass
    asyncio.run(run())


def stop_monitor():
    _stop.set()
    if _loop and _client:
        try: asyncio.run_coroutine_threadsafe(_client.disconnect(), _loop)
        except Exception: pass
